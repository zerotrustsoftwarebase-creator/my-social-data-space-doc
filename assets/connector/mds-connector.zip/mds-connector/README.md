# My (Social) Data Space — machine connector

Carries readings from a machine you run — a camera system, a sensor hub, a
server, a script — into a topic on your phone.

It can only do what you approve on the phone: one topic, the fields you pick,
a rate and an end date. It cannot widen any of that, and it never sees
anything you did not grant.

## Install

```sh
python3 -m pip install --user cryptography
python3 mds_connector.py check
```

`check` proves the ciphers against their published test vectors and pushes on
every refusal this connector relies on. If it prints anything else, stop.

## Use

```sh
python3 mds_connector.py profiles                      # machines it already knows
python3 mds_connector.py fields  --profile frigate     # the topic to make in the app
python3 mds_connector.py preview --profile frigate     # what it would add — writes nothing
python3 mds_connector.py connect --profile frigate \
    --topic <topic id> --invite '<invite from the app>' --every 30
python3 mds_connector.py run     --profile frigate --topic <topic id> --every 30
```

`preview` needs no phone and no permission. Everything else needs an invite you
create in the app under **My data → Connected tools**.

### Machines with a self-signed certificate

HTTPS to the machine is verified like any other client verifies it, and a
certificate that does not verify is refused before the sign-in is sent. Many
home-network machines use a certificate they made themselves; for those, opt in
explicitly — there is no switch that turns checking off:

- `--pin-machine-certificate` trusts the certificate the machine presents the
  first time, prints its SHA-256 fingerprint (compare it with the one the
  machine shows), saves it in `~/.mds-connector/machine-certificates.json`, and
  refuses any other certificate at that address from then on.
- `--machine-certificate-sha256 <fingerprint>` trusts only the certificate with
  that fingerprint, without trusting anything on first use.
- `--certificate-pins <file>` keeps the pins somewhere else.

Credentials (the `Authorization` header and a sign-in cookie) are sent to the
machine's own address only: a redirect to another host, port or scheme is
followed without them.

### Phone app version

This connector speaks nearby protocol `mds/2`. Phones on app versions 20 and 21
speak `mds/1` and refuse it (and it refuses them) by name — update the app.
Each connection is encrypted with keys agreed from throwaway keys made for that
connection alone and forgotten straight after, so a recording of it cannot be
read later even with this connector's stored identity; a message lost, reordered
or repeated on the way ends the connection instead of being acted on.
`python3 mds_connector.py check` proves the session cipher against the same
known answer the app is tested with.
Invites start with `mds-tool-invite.v2.` and carry a fingerprint of the phone's
identity: the connector refuses a device at the invite's address whose proved
identity does not match, before offering anything. When it offers itself it
prints a verification code; approve on the phone only if the phone shows the
same code.

## Where things live

- `mds_connector.py` — the whole program.
- `profiles/` — one JSON file per machine. A profile says where the records
  live, how to sign in, and how one record becomes one entry.
- `~/.mds-connector/credentials` — the machine's address and sign-in, as
  `key: value` lines. Never put these in a profile.
- `~/.mds-connector/<topic-slug>.json` — this connector's own key and its
  progress. **Treat it as a secret and back it up**: the permission on the
  phone was issued to the key in that file, so losing it means connecting
  again and being reviewed again.

Credentials can also come from the environment, as `MDS_<KEY>` — for the `link`
key that is `MDS_LINK`.

## Adding a machine

Copy the closest profile and change only its address, sign-in, record
selection, topic fields and mapping. Then `fields` and `preview` again before
you connect anything.

The mapping vocabulary is deliberately small — `text`, `number`, `duration`,
`time`, `join`, `count`, `constant`. If a machine needs a rule this connector
does not know, it is not safe to hide that behaviour in JSON.
