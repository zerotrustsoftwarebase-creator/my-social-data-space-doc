# My (Social) Data Space — machine connector

Carries readings from a machine you run — a camera system, a sensor hub, a
server, a script — into a topic on your phone.

It can only do what you approve on the phone: one topic, the fields you pick,
a rate and an end date. It cannot widen any of that, and it never sees
anything you did not grant.

## Install

```sh
python3 -m pip install --user cryptography
python3 mds_connector.py check
```

`check` proves the ciphers against their published test vectors and pushes on
every refusal this connector relies on. If it prints anything else, stop.

## Use

```sh
python3 mds_connector.py profiles                      # machines it already knows
python3 mds_connector.py fields  --profile frigate     # the topic to make in the app
python3 mds_connector.py preview --profile frigate     # what it would add — writes nothing
python3 mds_connector.py connect --profile frigate \
    --topic <topic id> --invite '<invite from the app>' --every 30
python3 mds_connector.py run     --profile frigate --topic <topic id> --every 30
```

`preview` needs no phone and no permission. Everything else needs an invite you
create in the app under **My data → Connected tools**.

## Where things live

- `mds_connector.py` — the whole program.
- `profiles/` — one JSON file per machine. A profile says where the records
  live, how to sign in, and how one record becomes one entry.
- `~/.mds-connector/credentials` — the machine's address and sign-in, as
  `key: value` lines. Never put these in a profile.
- `~/.mds-connector/<topic-slug>.json` — this connector's own key and its
  progress. **Treat it as a secret and back it up**: the permission on the
  phone was issued to the key in that file, so losing it means connecting
  again and being reviewed again.

Credentials can also come from the environment, as `MDS_<KEY>` — for the `link`
key that is `MDS_LINK`.

## Adding a machine

Copy the closest profile and change only its address, sign-in, record
selection, topic fields and mapping. Then `fields` and `preview` again before
you connect anything.

The mapping vocabulary is deliberately small — `text`, `number`, `duration`,
`time`, `join`, `count`, `constant`. If a machine needs a rule this connector
does not know, it is not safe to hide that behaviour in JSON.
